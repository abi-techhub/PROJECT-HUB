// Seed script: fills the database with sample data so the app looks alive on first run.
// Run with: bun scripts/seed.ts
import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

// Helper: create a Date N days from today (date only, UTC midnight)
function daysFromNow(n: number) {
  const d = new Date()
  d.setUTCHours(0, 0, 0, 0)
  d.setUTCDate(d.getUTCDate() + n)
  return d
}

async function main() {
  // Only seed if the database is empty (so we never duplicate data)
  const existing = await db.client.count()
  if (existing > 0) {
    console.log('Database already has data — skipping seed.')
    return
  }

  const acme = await db.client.create({
    data: { name: 'Sarah Mitchell', company: 'Acme Corporation', email: 'sarah@acme.com', phone: '+1 555-0101' },
  })
  const bright = await db.client.create({
    data: { name: 'James Chen', company: 'Bright Ideas Studio', email: 'james@brightideas.io', phone: '+1 555-0102' },
  })
  const northwind = await db.client.create({
    data: { name: 'Elena Rodriguez', company: 'Northwind Traders', email: 'elena@northwind.com', phone: '+1 555-0103' },
  })
  const summit = await db.client.create({
    data: { name: 'David Kim', company: 'Summit Legal Group', email: 'david@summitlegal.com', phone: '+1 555-0104' },
  })

  const website = await db.project.create({
    data: {
      name: 'Website Redesign',
      description: 'Complete overhaul of the marketing website with a fresh look and faster pages.',
      status: 'IN_PROGRESS',
      priority: 'HIGH',
      deadline: daysFromNow(12),
      clientId: acme.id,
    },
  })
  const app = await db.project.create({
    data: {
      name: 'Mobile App MVP',
      description: 'First version of the iOS and Android app with login, feed and notifications.',
      status: 'IN_PROGRESS',
      priority: 'MEDIUM',
      deadline: daysFromNow(28),
      clientId: bright.id,
    },
  })
  await db.project.create({
    data: {
      name: 'Brand Identity Package',
      description: 'Logo refresh, color palette, typography and brand guidelines book.',
      status: 'PLANNING',
      priority: 'LOW',
      deadline: daysFromNow(45),
      clientId: northwind.id,
    },
  })
  await db.project.create({
    data: {
      name: 'CRM Migration',
      description: 'Move customer records from the old system to the new CRM platform.',
      status: 'ON_HOLD',
      priority: 'MEDIUM',
      deadline: daysFromNow(20),
      clientId: summit.id,
    },
  })
  const campaign = await db.project.create({
    data: {
      name: 'Q3 Marketing Campaign',
      description: 'Seasonal campaign across email, social media and paid ads.',
      status: 'COMPLETED',
      priority: 'HIGH',
      deadline: daysFromNow(-4),
      clientId: acme.id,
    },
  })

  const task = (title: string, status: string, due: Date | null, projectId: string) =>
    db.task.create({ data: { title, status, dueDate: due, projectId } })

  await Promise.all([
    task('Design homepage wireframes', 'DONE', daysFromNow(-10), website.id),
    task('Write new website copy', 'DONE', daysFromNow(-6), website.id),
    task('Build responsive page templates', 'IN_PROGRESS', daysFromNow(4), website.id),
    task('Set up contact forms', 'TODO', daysFromNow(8), website.id),
    task('Cross-browser testing', 'TODO', daysFromNow(11), website.id),

    task('Set up app navigation', 'DONE', daysFromNow(-8), app.id),
    task('Build login screen', 'DONE', daysFromNow(-3), app.id),
    task('Create news feed UI', 'IN_PROGRESS', daysFromNow(6), app.id),
    task('Add push notifications', 'TODO', daysFromNow(18), app.id),

    task('Kick-off meeting notes', 'DONE', daysFromNow(-2), campaign.id),
    task('Schedule social posts', 'DONE', daysFromNow(-12), campaign.id),
    task('Final campaign report', 'DONE', daysFromNow(-5), campaign.id),
  ])

  console.log('✅ Sample data created: 4 clients, 5 projects, 12 tasks')
}

main()
  .catch(console.error)
  .finally(() => db.$disconnect())
