// The Projects page — a grid of project cards with search, filters, and edit/delete.
'use client'

import { useMemo, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { ProjectStatusBadge, PriorityBadge, DeadlineChip } from '@/components/hub/badges'
import { projectProgress, PROJECT_STATUS_CONFIG, type ProjectItem, type ProjectStatus } from '@/lib/hub'
import {
  Plus,
  Search,
  MoreVertical,
  Pencil,
  Trash2,
  Building2,
  FolderKanban,
  ListChecks,
} from 'lucide-react'

interface ProjectsViewProps {
  projects: ProjectItem[]
  loading: boolean
  onNew: () => void
  onEdit: (project: ProjectItem) => void
  onDelete: (project: ProjectItem) => void
  onAddTask: (project: ProjectItem) => void
}

export function ProjectsView({ projects, loading, onNew, onEdit, onDelete, onAddTask }: ProjectsViewProps) {
  // Search text + status filter (local to this screen, resets on reload)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('ALL')

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase()
    return projects.filter((p) => {
      const matchesSearch =
        term === '' ||
        p.name.toLowerCase().includes(term) ||
        (p.client?.company ?? '').toLowerCase().includes(term) ||
        (p.client?.name ?? '').toLowerCase().includes(term)
      const matchesStatus = statusFilter === 'ALL' || p.status === statusFilter
      return matchesSearch && matchesStatus
    })
  }, [projects, search, statusFilter])

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Projects</h1>
          <p className="text-sm text-muted-foreground">
            {projects.length} {projects.length === 1 ? 'project' : 'projects'} in your hub
          </p>
        </div>
        <Button onClick={onNew}>
          <Plus className="mr-2 h-4 w-4" /> New Project
        </Button>
      </div>

      {/* Search + filter bar */}
      <div className="flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search projects or clients..."
            className="pl-9"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-44">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All statuses</SelectItem>
            {(Object.keys(PROJECT_STATUS_CONFIG) as ProjectStatus[]).map((status) => (
              <SelectItem key={status} value={status}>
                {PROJECT_STATUS_CONFIG[status].label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Loading skeletons */}
      {loading && projects.length === 0 && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-64" />
          ))}
        </div>
      )}

      {/* Project cards */}
      {!loading && filtered.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <FolderKanban className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="font-medium">{projects.length === 0 ? 'No projects yet' : 'No matches found'}</p>
              <p className="text-sm text-muted-foreground">
                {projects.length === 0
                  ? 'Create your first project to get started.'
                  : 'Try a different search term or filter.'}
              </p>
            </div>
            {projects.length === 0 && (
              <Button onClick={onNew}>
                <Plus className="mr-2 h-4 w-4" /> New Project
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((project) => (
            <ProjectCard
              key={project.id}
              project={project}
              onEdit={() => onEdit(project)}
              onDelete={() => onDelete(project)}
              onAddTask={() => onAddTask(project)}
            />
          ))}
        </div>
      )}
    </div>
  )
}

// ---------- One project card ----------

function ProjectCard({
  project,
  onEdit,
  onDelete,
  onAddTask,
}: {
  project: ProjectItem
  onEdit: () => void
  onDelete: () => void
  onAddTask: () => void
}) {
  const progress = projectProgress(project)
  const doneTasks = project.tasks.filter((t) => t.status === 'DONE').length

  return (
    <Card className="group py-0 transition-all hover:-translate-y-0.5 hover:shadow-md">
      <CardContent className="flex h-full flex-col gap-4 p-5">
        {/* Title + actions menu */}
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <h3 className="truncate font-semibold leading-snug">{project.name}</h3>
            <p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
              <Building2 className="h-3 w-3 shrink-0" />
              <span className="truncate">
                {project.client ? project.client.company || project.client.name : 'No client'}
              </span>
            </p>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0 text-muted-foreground"
                aria-label={`Actions for ${project.name}`}
              >
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit}>
                <Pencil className="mr-2 h-4 w-4" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onAddTask}>
                <ListChecks className="mr-2 h-4 w-4" /> Add task
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive">
                <Trash2 className="mr-2 h-4 w-4" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Badges */}
        <div className="flex flex-wrap items-center gap-2">
          <ProjectStatusBadge status={project.status} />
          <PriorityBadge priority={project.priority} />
        </div>

        {/* Description */}
        {project.description && (
          <p className="line-clamp-2 text-sm text-muted-foreground">{project.description}</p>
        )}

        {/* Progress */}
        <div className="mt-auto space-y-2">
          <div className="flex items-center gap-3">
            <Progress value={progress} className="h-2 flex-1" />
            <span className="w-10 text-right text-xs font-semibold tabular-nums">{progress}%</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-xs text-muted-foreground">
              {doneTasks} of {project.tasks.length} tasks done
            </span>
            <DeadlineChip date={project.deadline} />
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
