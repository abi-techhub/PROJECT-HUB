// The Dashboard — the first screen you see.
// Shows summary cards, project progress bars, and upcoming deadlines.
'use client'

import { useMemo } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import { ProjectStatusBadge, DeadlineChip } from '@/components/hub/badges'
import {
  daysUntil,
  projectProgress,
  formatDate,
  type ClientItem,
  type ProjectItem,
} from '@/lib/hub'
import {
  FolderKanban,
  CheckCircle2,
  ListChecks,
  CalendarClock,
  Plus,
  Building2,
  ChevronRight,
  LayoutDashboard,
} from 'lucide-react'

export type TabKey = 'dashboard' | 'projects' | 'clients' | 'tasks'

interface DashboardViewProps {
  projects: ProjectItem[]
  clients: ClientItem[]
  loading: boolean
  onNewProject: () => void
  onEditProject: (project: ProjectItem) => void
  onNavigate: (tab: TabKey) => void
}

export function DashboardView({ projects, clients, loading, onNewProject, onEditProject, onNavigate }: DashboardViewProps) {
  // useMemo = "calculate this only when the data changes", not on every render
  const stats = useMemo(() => {
    const active = projects.filter((p) => p.status !== 'COMPLETED')
    const completed = projects.filter((p) => p.status === 'COMPLETED')
    const allTasks = projects.flatMap((p) => p.tasks)
    const doneTasks = allTasks.filter((t) => t.status === 'DONE')
    const openTasks = allTasks.filter((t) => t.status !== 'DONE')

    // Projects due within the next 7 days (and not finished)
    const dueThisWeek = projects.filter((p) => {
      if (p.status === 'COMPLETED' || !p.deadline) return false
      const days = daysUntil(p.deadline)
      return days >= 0 && days <= 7
    })

    const avgProgress =
      projects.length > 0
        ? Math.round(projects.reduce((sum, p) => sum + projectProgress(p), 0) / projects.length)
        : 0

    return { active, completed, allTasks, doneTasks, openTasks, dueThisWeek, avgProgress }
  }, [projects])

  // Projects for the progress list: not completed, closest deadline first
  const progressList = useMemo(() => {
    return [...projects]
      .filter((p) => p.status !== 'COMPLETED')
      .sort((a, b) => {
        if (!a.deadline) return 1
        if (!b.deadline) return -1
        return a.deadline.localeCompare(b.deadline)
      })
  }, [projects])

  // Upcoming deadlines: mix of project deadlines and task due dates
  const upcoming = useMemo(() => {
    const items: Array<{ id: string; kind: 'project' | 'task'; label: string; sub: string; date: string }> = []
    for (const p of projects) {
      if (p.deadline && p.status !== 'COMPLETED') {
        items.push({ id: `p-${p.id}`, kind: 'project', label: p.name, sub: 'Project deadline', date: p.deadline })
      }
      for (const t of p.tasks) {
        if (t.dueDate && t.status !== 'DONE') {
          items.push({ id: `t-${t.id}`, kind: 'task', label: t.title, sub: p.name, date: t.dueDate })
        }
      }
    }
    return items.sort((a, b) => a.date.localeCompare(b.date)).slice(0, 8)
  }, [projects])

  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  })

  // First load: show grey placeholder boxes
  if (loading && projects.length === 0) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
        <div className="grid gap-6 lg:grid-cols-3">
          <Skeleton className="h-80 lg:col-span-2" />
          <Skeleton className="h-80" />
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Welcome header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Welcome back</h1>
          <p className="text-sm text-muted-foreground">{today}</p>
        </div>
        <Button onClick={onNewProject}>
          <Plus className="mr-2 h-4 w-4" />
          New Project
        </Button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          icon={<FolderKanban className="h-5 w-5" />}
          label="Active Projects"
          value={String(stats.active.length)}
          sub={`${projects.length} total`}
          iconClass="bg-emerald-100 text-emerald-600 dark:bg-emerald-500/15 dark:text-emerald-400"
          onClick={() => onNavigate('projects')}
        />
        <StatCard
          icon={<CheckCircle2 className="h-5 w-5" />}
          label="Completed"
          value={String(stats.completed.length)}
          sub={`${stats.avgProgress}% avg. progress`}
          iconClass="bg-slate-200 text-slate-600 dark:bg-slate-500/15 dark:text-slate-300"
          onClick={() => onNavigate('projects')}
        />
        <StatCard
          icon={<ListChecks className="h-5 w-5" />}
          label="Open Tasks"
          value={String(stats.openTasks.length)}
          sub={`${stats.doneTasks.length} of ${stats.allTasks.length} done`}
          iconClass="bg-violet-100 text-violet-600 dark:bg-violet-500/15 dark:text-violet-400"
          onClick={() => onNavigate('tasks')}
        />
        <StatCard
          icon={<CalendarClock className="h-5 w-5" />}
          label="Due This Week"
          value={String(stats.dueThisWeek.length)}
          sub={`${clients.length} active clients`}
          iconClass="bg-amber-100 text-amber-600 dark:bg-amber-500/15 dark:text-amber-400"
          onClick={() => onNavigate('tasks')}
        />
      </div>

      {/* Progress + deadlines */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Project progress list */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-4">
            <CardTitle className="text-base font-semibold">Project Progress</CardTitle>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('projects')}>
              View all <ChevronRight className="ml-1 h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {progressList.length === 0 && (
              <EmptyHint text="No active projects right now. Create one to start tracking progress." onAction={onNewProject} actionLabel="New Project" />
            )}
            <div className="thin-scrollbar max-h-96 space-y-4 overflow-y-auto pr-1">
              {progressList.map((project) => {
                const progress = projectProgress(project)
                const done = project.tasks.filter((t) => t.status === 'DONE').length
                return (
                  <button
                    key={project.id}
                    onClick={() => onEditProject(project)}
                    className="group block w-full rounded-lg border border-transparent p-3 text-left transition-colors hover:border-border hover:bg-accent/50"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="truncate font-medium">{project.name}</p>
                        <p className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Building2 className="h-3 w-3" />
                          {project.client ? project.client.company || project.client.name : 'No client'}
                        </p>
                      </div>
                      <ProjectStatusBadge status={project.status} />
                    </div>
                    <div className="mt-3 flex items-center gap-3">
                      <Progress value={progress} className="h-2 flex-1" />
                      <span className="w-10 text-right text-xs font-semibold tabular-nums">{progress}%</span>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="text-xs text-muted-foreground">
                        {done} of {project.tasks.length} tasks done
                      </span>
                      <DeadlineChip date={project.deadline} />
                    </div>
                  </button>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming deadlines */}
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-base font-semibold">Upcoming Deadlines</CardTitle>
          </CardHeader>
          <CardContent>
            {upcoming.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">
                Nothing due soon. Enjoy the quiet!
              </p>
            ) : (
              <div className="thin-scrollbar max-h-96 space-y-1 overflow-y-auto pr-1">
                {upcoming.map((item) => {
                  const days = daysUntil(item.date)
                  const overdue = days < 0
                  return (
                    <div
                      key={item.id}
                      className="flex items-start gap-3 rounded-lg p-2 transition-colors hover:bg-accent/50"
                    >
                      <span
                        className={
                          overdue
                            ? 'mt-1.5 h-2 w-2 shrink-0 rounded-full bg-rose-500'
                            : days <= 3
                              ? 'mt-1.5 h-2 w-2 shrink-0 rounded-full bg-amber-500'
                              : 'mt-1.5 h-2 w-2 shrink-0 rounded-full bg-emerald-500'
                        }
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">{item.label}</p>
                        <p className="truncate text-xs text-muted-foreground">
                          {item.kind === 'project' ? 'Deadline · ' : 'Task · '}
                          {item.sub}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className={`text-xs ${overdue ? 'font-semibold text-rose-600 dark:text-rose-400' : 'text-muted-foreground'}`}>
                          {overdue ? `${Math.abs(days)}d late` : days === 0 ? 'Today' : `${days}d`}
                        </p>
                        <p className="text-[11px] text-muted-foreground/80">{formatDate(item.date)}</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Empty-state hero when there is no data at all */}
      {projects.length === 0 && !loading && (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-3 py-10 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <LayoutDashboard className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="font-medium">Your hub is empty</p>
              <p className="text-sm text-muted-foreground">Add a client, create a project and break it into tasks.</p>
            </div>
            <Button onClick={onNewProject}>
              <Plus className="mr-2 h-4 w-4" /> Create your first project
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// ---------- small helper components used only in this file ----------

function StatCard({
  icon,
  label,
  value,
  sub,
  iconClass,
  onClick,
}: {
  icon: React.ReactNode
  label: string
  value: string
  sub: string
  iconClass: string
  onClick?: () => void
}) {
  return (
    <Card
      onClick={onClick}
      className="cursor-pointer py-0 transition-all hover:-translate-y-0.5 hover:shadow-md"
    >
      <CardContent className="flex items-center gap-4 p-5">
        <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${iconClass}`}>
          {icon}
        </div>
        <div className="min-w-0">
          <p className="truncate text-xs font-medium text-muted-foreground">{label}</p>
          <p className="text-2xl font-bold leading-tight tabular-nums">{value}</p>
          <p className="truncate text-xs text-muted-foreground/80">{sub}</p>
        </div>
      </CardContent>
    </Card>
  )
}

function EmptyHint({ text, onAction, actionLabel }: { text: string; onAction: () => void; actionLabel: string }) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-lg border border-dashed py-8 text-center">
      <p className="max-w-xs text-sm text-muted-foreground">{text}</p>
      <Button size="sm" variant="outline" onClick={onAction}>
        <Plus className="mr-2 h-4 w-4" /> {actionLabel}
      </Button>
    </div>
  )
}
