// The Tasks page — every task across all projects.
// Click the circle button to move a task: To Do → In Progress → Done.
'use client'

import { useMemo, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { TaskStatusBadge, DeadlineChip } from '@/components/hub/badges'
import { TASK_STATUS_CONFIG, type ProjectItem, type TaskItem, type TaskStatus } from '@/lib/hub'
import { cn } from '@/lib/utils'
import {
  Plus,
  Search,
  Circle,
  CircleDot,
  CheckCircle2,
  Pencil,
  Trash2,
  ListChecks,
  FolderKanban,
} from 'lucide-react'

interface TasksViewProps {
  tasks: TaskItem[] // flat list built from all projects
  projects: ProjectItem[]
  loading: boolean
  onNew: () => void
  onEdit: (task: TaskItem) => void
  onDelete: (task: TaskItem) => void
  onCycleStatus: (task: TaskItem) => void
}

const NEXT_STATUS: Record<TaskStatus, TaskStatus> = {
  TODO: 'IN_PROGRESS',
  IN_PROGRESS: 'DONE',
  DONE: 'TODO',
}

export function TasksView({ tasks, projects, loading, onNew, onEdit, onDelete, onCycleStatus }: TasksViewProps) {
  const [search, setSearch] = useState('')
  const [projectFilter, setProjectFilter] = useState('ALL')
  const [statusFilter, setStatusFilter] = useState('ALL')

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase()
    const order: Record<TaskStatus, number> = { IN_PROGRESS: 0, TODO: 1, DONE: 2 }
    return tasks
      .filter((t) => {
        const matchesSearch = term === '' || t.title.toLowerCase().includes(term)
        const matchesProject = projectFilter === 'ALL' || t.projectId === projectFilter
        const matchesStatus = statusFilter === 'ALL' || t.status === statusFilter
        return matchesSearch && matchesProject && matchesStatus
      })
      .sort((a, b) => {
        // unfinished first, then by due date
        if (order[a.status] !== order[b.status]) return order[a.status] - order[b.status]
        if (a.dueDate && b.dueDate) return a.dueDate.localeCompare(b.dueDate)
        if (a.dueDate) return -1
        if (b.dueDate) return 1
        return 0
      })
  }, [tasks, search, projectFilter, statusFilter])

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Tasks</h1>
          <p className="text-sm text-muted-foreground">
            {tasks.filter((t) => t.status !== 'DONE').length} open ·{' '}
            {tasks.filter((t) => t.status === 'DONE').length} done
          </p>
        </div>
        <Button onClick={onNew} disabled={projects.length === 0}>
          <Plus className="mr-2 h-4 w-4" /> New Task
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 lg:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search tasks..."
            className="pl-9"
          />
        </div>
        <div className="flex gap-3">
          <Select value={projectFilter} onValueChange={setProjectFilter}>
            <SelectTrigger className="w-full lg:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All projects</SelectItem>
              {projects.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-full lg:w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All statuses</SelectItem>
              {(Object.keys(TASK_STATUS_CONFIG) as TaskStatus[]).map((s) => (
                <SelectItem key={s} value={s}>
                  {TASK_STATUS_CONFIG[s].label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Loading skeletons */}
      {loading && tasks.length === 0 && (
        <div className="space-y-2">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-16" />
          ))}
        </div>
      )}

      {/* Task list */}
      {!loading && filtered.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <ListChecks className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="font-medium">
                {tasks.length === 0 ? 'No tasks yet' : projects.length === 0 ? 'Create a project first' : 'No matches found'}
              </p>
              <p className="text-sm text-muted-foreground">
                {tasks.length === 0
                  ? projects.length === 0
                    ? 'Tasks live inside projects — create a project first.'
                    : 'Break your projects into small steps by adding tasks.'
                  : 'Try different filters or search.'}
              </p>
            </div>
            {tasks.length === 0 && projects.length > 0 && (
              <Button onClick={onNew}>
                <Plus className="mr-2 h-4 w-4" /> New Task
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <Card className="py-0">
          <CardContent className="divide-y p-0">
            {filtered.map((task) => (
              <TaskRow
                key={task.id}
                task={task}
                onCycle={() => onCycleStatus(task)}
                onEdit={() => onEdit(task)}
                onDelete={() => onDelete(task)}
              />
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  )
}

// ---------- One task row ----------

function TaskRow({
  task,
  onCycle,
  onEdit,
  onDelete,
}: {
  task: TaskItem
  onCycle: () => void
  onEdit: () => void
  onDelete: () => void
}) {
  const isDone = task.status === 'DONE'

  // The round button on the left changes with the status
  const statusButton = {
    TODO: { icon: <Circle className="h-5 w-5" />, class: 'text-muted-foreground/50 hover:text-amber-600 hover:border-amber-300' },
    IN_PROGRESS: { icon: <CircleDot className="h-5 w-5" />, class: 'text-violet-500 hover:text-violet-600 border-violet-300 dark:border-violet-500/40' },
    DONE: { icon: <CheckCircle2 className="h-5 w-5" />, class: 'text-emerald-500 hover:text-emerald-600 border-emerald-300 dark:border-emerald-500/40' },
  }[task.status]

  return (
    <div className="flex items-center gap-3 px-4 py-3 transition-colors hover:bg-accent/40 sm:px-5">
      {/* Status cycle button */}
      <button
        onClick={onCycle}
        aria-label={`Change status of "${task.title}" (currently ${TASK_STATUS_CONFIG[task.status].label})`}
        title={`Click to move to ${TASK_STATUS_CONFIG[NEXT_STATUS[task.status]].label}`}
        className={cn(
          'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-2 bg-transparent transition-colors',
          statusButton.class
        )}
      >
        {statusButton.icon}
      </button>

      {/* Title + project */}
      <div className="min-w-0 flex-1">
        <p className={cn('truncate text-sm font-medium', isDone && 'text-muted-foreground line-through')}>
          {task.title}
        </p>
        <p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
          <FolderKanban className="h-3 w-3 shrink-0" />
          <span className="truncate">{task.project?.name ?? 'Unknown project'}</span>
        </p>
      </div>

      {/* Badges + due date (hidden on tiny screens) */}
      <div className="hidden shrink-0 items-center gap-3 sm:flex">
        <TaskStatusBadge status={task.status} />
        <DeadlineChip date={task.dueDate} />
      </div>

      {/* Row actions */}
      <div className="flex shrink-0 items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-muted-foreground"
          onClick={onEdit}
          aria-label={`Edit ${task.title}`}
        >
          <Pencil className="h-4 w-4" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          className="h-8 w-8 text-muted-foreground hover:text-destructive"
          onClick={onDelete}
          aria-label={`Delete ${task.title}`}
        >
          <Trash2 className="h-4 w-4" />
        </Button>
      </div>
    </div>
  )
}
