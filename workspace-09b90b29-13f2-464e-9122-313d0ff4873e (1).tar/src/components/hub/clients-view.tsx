// The Clients page — cards for every client with contact info and project counts.
'use client'

import { useMemo, useState } from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { initials, type ClientItem } from '@/lib/hub'
import { Plus, Search, MoreVertical, Pencil, Trash2, Mail, Phone, Users, FolderKanban } from 'lucide-react'

interface ClientsViewProps {
  clients: ClientItem[]
  loading: boolean
  onNew: () => void
  onEdit: (client: ClientItem) => void
  onDelete: (client: ClientItem) => void
}

export function ClientsView({ clients, loading, onNew, onEdit, onDelete }: ClientsViewProps) {
  const [search, setSearch] = useState('')

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase()
    if (term === '') return clients
    return clients.filter(
      (c) =>
        c.name.toLowerCase().includes(term) ||
        (c.company ?? '').toLowerCase().includes(term) ||
        (c.email ?? '').toLowerCase().includes(term)
    )
  }, [clients, search])

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Clients</h1>
          <p className="text-sm text-muted-foreground">
            {clients.length} {clients.length === 1 ? 'client' : 'clients'} you work with
          </p>
        </div>
        <Button onClick={onNew}>
          <Plus className="mr-2 h-4 w-4" /> New Client
        </Button>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search clients..."
          className="pl-9"
        />
      </div>

      {/* Loading skeletons */}
      {loading && clients.length === 0 && (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-40" />
          ))}
        </div>
      )}

      {/* Client cards */}
      {!loading && filtered.length === 0 ? (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="font-medium">{clients.length === 0 ? 'No clients yet' : 'No matches found'}</p>
              <p className="text-sm text-muted-foreground">
                {clients.length === 0
                  ? 'Add your first client to link projects to them.'
                  : 'Try a different search term.'}
              </p>
            </div>
            {clients.length === 0 && (
              <Button onClick={onNew}>
                <Plus className="mr-2 h-4 w-4" /> New Client
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((client) => (
            <ClientCard key={client.id} client={client} onEdit={() => onEdit(client)} onDelete={() => onDelete(client)} />
          ))}
        </div>
      )}
    </div>
  )
}

// ---------- One client card ----------

function ClientCard({
  client,
  onEdit,
  onDelete,
}: {
  client: ClientItem
  onEdit: () => void
  onDelete: () => void
}) {
  const projectCount = client._count?.projects ?? 0

  return (
    <Card className="py-0 transition-all hover:-translate-y-0.5 hover:shadow-md">
      <CardContent className="flex h-full flex-col gap-3 p-5">
        {/* Avatar + name + actions */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-primary font-semibold text-primary-foreground">
              {initials(client.name)}
            </div>
            <div className="min-w-0">
              <h3 className="truncate font-semibold leading-snug">{client.name}</h3>
              <p className="truncate text-xs text-muted-foreground">{client.company || 'Independent'}</p>
            </div>
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 shrink-0 text-muted-foreground"
                aria-label={`Actions for ${client.name}`}
              >
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={onEdit}>
                <Pencil className="mr-2 h-4 w-4" /> Edit
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onDelete} className="text-destructive focus:text-destructive">
                <Trash2 className="mr-2 h-4 w-4" /> Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Contact info */}
        <div className="space-y-1.5 text-sm text-muted-foreground">
          {client.email && (
            <p className="flex items-center gap-2 truncate">
              <Mail className="h-3.5 w-3.5 shrink-0" />
              <span className="truncate">{client.email}</span>
            </p>
          )}
          {client.phone && (
            <p className="flex items-center gap-2">
              <Phone className="h-3.5 w-3.5 shrink-0" />
              {client.phone}
            </p>
          )}
        </div>

        {/* Project count */}
        <div className="mt-auto pt-1">
          <Badge variant="secondary" className="gap-1.5 font-medium">
            <FolderKanban className="h-3 w-3" />
            {projectCount} {projectCount === 1 ? 'project' : 'projects'}
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
