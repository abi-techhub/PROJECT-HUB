// Small colored labels (badges) used across the app.
'use client'

import { Badge } from '@/components/ui/badge'
import {
  deadlineLabel,
  PROJECT_STATUS_CONFIG,
  PRIORITY_CONFIG,
  TASK_STATUS_CONFIG,
  toneClasses,
  type ProjectPriority,
  type ProjectStatus,
  type TaskStatus,
} from '@/lib/hub'
import { cn } from '@/lib/utils'

// Example: <ProjectStatusBadge status="IN_PROGRESS" /> → green "In Progress"
export function ProjectStatusBadge({ status }: { status: ProjectStatus }) {
  const config = PROJECT_STATUS_CONFIG[status]
  return (
    <Badge variant="outline" className={cn('font-medium', toneClasses(config.tone))}>
      {config.label}
    </Badge>
  )
}

export function PriorityBadge({ priority }: { priority: ProjectPriority }) {
  const config = PRIORITY_CONFIG[priority]
  return (
    <Badge variant="outline" className={cn('font-medium', toneClasses(config.tone))}>
      {config.label}
    </Badge>
  )
}

export function TaskStatusBadge({ status }: { status: TaskStatus }) {
  const config = TASK_STATUS_CONFIG[status]
  return (
    <Badge variant="outline" className={cn('font-medium', toneClasses(config.tone))}>
      {config.label}
    </Badge>
  )
}

// Deadline chip that turns amber when close and red when overdue
export function DeadlineChip({ date }: { date: string | null }) {
  const { text, tone } = deadlineLabel(date)
  const toneMap: Record<string, string> = {
    danger: 'text-rose-600 dark:text-rose-400 font-medium',
    warn: 'text-amber-600 dark:text-amber-400 font-medium',
    ok: 'text-muted-foreground',
    muted: 'text-muted-foreground/70',
  }
  return <span className={cn('text-xs', toneMap[tone])}>{text}</span>
}
