// API route for /api/projects/[id] — a single project
// PUT    → update an existing project
// DELETE → remove a project (its tasks are removed too, automatically)

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const STATUSES = ['PLANNING', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED']
const PRIORITIES = ['LOW', 'MEDIUM', 'HIGH']

// PUT /api/projects/[id] — update a project
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()

    if (!body.name || typeof body.name !== 'string' || !body.name.trim()) {
      return NextResponse.json({ error: 'Project name is required' }, { status: 400 })
    }

    const status = STATUSES.includes(body.status) ? body.status : 'PLANNING'
    const priority = PRIORITIES.includes(body.priority) ? body.priority : 'MEDIUM'

    const project = await db.project.update({
      where: { id },
      data: {
        name: body.name.trim(),
        description: body.description?.trim() || null,
        status,
        priority,
        deadline: body.deadline ? new Date(body.deadline) : null,
        clientId: body.clientId || null,
      },
    })
    return NextResponse.json(project)
  } catch (error) {
    console.error('PUT /api/projects/[id] failed:', error)
    return NextResponse.json({ error: 'Could not update project' }, { status: 500 })
  }
}

// DELETE /api/projects/[id] — remove a project
export async function DELETE(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    await db.project.delete({ where: { id } }) // tasks disappear automatically (Cascade)
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error('DELETE /api/projects/[id] failed:', error)
    return NextResponse.json({ error: 'Could not delete project' }, { status: 500 })
  }
}
