// API route for /api/projects
// GET  → returns all projects, each with its client and its tasks included
// POST → creates a new project

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Allowed status / priority values (keeps bad data out)
const STATUSES = ['PLANNING', 'IN_PROGRESS', 'ON_HOLD', 'COMPLETED']
const PRIORITIES = ['LOW', 'MEDIUM', 'HIGH']

// GET /api/projects — list every project with client + tasks
export async function GET() {
  try {
    const projects = await db.project.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        client: { select: { id: true, name: true, company: true } },
        tasks: { orderBy: { createdAt: 'asc' } },
      },
    })
    return NextResponse.json(projects)
  } catch (error) {
    console.error('GET /api/projects failed:', error)
    return NextResponse.json({ error: 'Could not load projects' }, { status: 500 })
  }
}

// POST /api/projects — create a new project
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    if (!body.name || typeof body.name !== 'string' || !body.name.trim()) {
      return NextResponse.json({ error: 'Project name is required' }, { status: 400 })
    }

    const status = STATUSES.includes(body.status) ? body.status : 'PLANNING'
    const priority = PRIORITIES.includes(body.priority) ? body.priority : 'MEDIUM'

    const project = await db.project.create({
      data: {
        name: body.name.trim(),
        description: body.description?.trim() || null,
        status,
        priority,
        // turn "2026-01-15" into a real Date, or null if empty
        deadline: body.deadline ? new Date(body.deadline) : null,
        clientId: body.clientId || null,
      },
    })
    return NextResponse.json(project, { status: 201 })
  } catch (error) {
    console.error('POST /api/projects failed:', error)
    return NextResponse.json({ error: 'Could not create project' }, { status: 500 })
  }
}
