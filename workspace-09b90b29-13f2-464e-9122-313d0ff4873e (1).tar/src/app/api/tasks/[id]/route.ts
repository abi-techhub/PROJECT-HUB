// API route for /api/tasks/[id] — a single task
// PUT    → update an existing task (title, status, due date…)
// DELETE → remove a task

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const STATUSES = ['TODO', 'IN_PROGRESS', 'DONE']

// PUT /api/tasks/[id] — update a task
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const body = await request.json()

    // Build only the fields that were sent, so we can also update just one field
    const data: Record<string, unknown> = {}
    if (body.title !== undefined) {
      if (!body.title.trim()) {
        return NextResponse.json({ error: 'Task title is required' }, { status: 400 })
      }
      data.title = body.title.trim()
    }
    if (body.status !== undefined && STATUSES.includes(body.status)) data.status = body.status
    if (body.dueDate !== undefined) data.dueDate = body.dueDate ? new Date(body.dueDate) : null
    if (body.projectId !== undefined && body.projectId) data.projectId = body.projectId

    const task = await db.task.update({
      where: { id },
      data,
      include: { project: { select: { id: true, name: true } } },
    })
    return NextResponse.json(task)
  } catch (error) {
    console.error('PUT /api/tasks/[id] failed:', error)
    return NextResponse.json({ error: 'Could not update task' }, { status: 500 })
  }
}

// DELETE /api/tasks/[id] — remove a task
export async function DELETE(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    await db.task.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error('DELETE /api/tasks/[id] failed:', error)
    return NextResponse.json({ error: 'Could not delete task' }, { status: 500 })
  }
}
