// API route for /api/tasks
// GET  → returns all tasks, each with its project name included
// POST → creates a new task

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const STATUSES = ['TODO', 'IN_PROGRESS', 'DONE']

// GET /api/tasks — list every task with its project
export async function GET() {
  try {
    const tasks = await db.task.findMany({
      orderBy: { createdAt: 'desc' },
      include: { project: { select: { id: true, name: true } } },
    })
    return NextResponse.json(tasks)
  } catch (error) {
    console.error('GET /api/tasks failed:', error)
    return NextResponse.json({ error: 'Could not load tasks' }, { status: 500 })
  }
}

// POST /api/tasks — create a new task
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    if (!body.title || typeof body.title !== 'string' || !body.title.trim()) {
      return NextResponse.json({ error: 'Task title is required' }, { status: 400 })
    }
    if (!body.projectId) {
      return NextResponse.json({ error: 'Task must belong to a project' }, { status: 400 })
    }

    const status = STATUSES.includes(body.status) ? body.status : 'TODO'

    const task = await db.task.create({
      data: {
        title: body.title.trim(),
        status,
        dueDate: body.dueDate ? new Date(body.dueDate) : null,
        projectId: body.projectId,
      },
      include: { project: { select: { id: true, name: true } } },
    })
    return NextResponse.json(task, { status: 201 })
  } catch (error) {
    console.error('POST /api/tasks failed:', error)
    return NextResponse.json({ error: 'Could not create task' }, { status: 500 })
  }
}
