// API route for /api/clients
// GET  → returns the list of all clients (with how many projects each has)
// POST → creates a new client

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/clients — list every client
export async function GET() {
  try {
    const clients = await db.client.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        _count: { select: { projects: true } }, // adds a counter: how many projects
      },
    })
    return NextResponse.json(clients)
  } catch (error) {
    console.error('GET /api/clients failed:', error)
    return NextResponse.json({ error: 'Could not load clients' }, { status: 500 })
  }
}

// POST /api/clients — create a new client
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Basic check: a client needs a name
    if (!body.name || typeof body.name !== 'string' || !body.name.trim()) {
      return NextResponse.json({ error: 'Client name is required' }, { status: 400 })
    }

    const client = await db.client.create({
      data: {
        name: body.name.trim(),
        company: body.company?.trim() || null,
        email: body.email?.trim() || null,
        phone: body.phone?.trim() || null,
      },
    })
    return NextResponse.json(client, { status: 201 })
  } catch (error) {
    console.error('POST /api/clients failed:', error)
    return NextResponse.json({ error: 'Could not create client' }, { status: 500 })
  }
}
