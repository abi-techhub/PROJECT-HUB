// API route for /api/clients/[id] — a single client
// PUT    → update an existing client
// DELETE → remove a client (their projects stay, just become "no client")

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// PUT /api/clients/[id] — update a client
export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params // in Next.js 16, params arrive as a Promise
    const body = await request.json()

    if (!body.name || typeof body.name !== 'string' || !body.name.trim()) {
      return NextResponse.json({ error: 'Client name is required' }, { status: 400 })
    }

    const client = await db.client.update({
      where: { id },
      data: {
        name: body.name.trim(),
        company: body.company?.trim() || null,
        email: body.email?.trim() || null,
        phone: body.phone?.trim() || null,
      },
    })
    return NextResponse.json(client)
  } catch (error) {
    console.error('PUT /api/clients/[id] failed:', error)
    return NextResponse.json({ error: 'Could not update client' }, { status: 500 })
  }
}

// DELETE /api/clients/[id] — remove a client
export async function DELETE(_request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    await db.client.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error('DELETE /api/clients/[id] failed:', error)
    return NextResponse.json({ error: 'Could not delete client' }, { status: 500 })
  }
}
