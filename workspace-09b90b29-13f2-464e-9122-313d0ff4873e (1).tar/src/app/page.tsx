// PROJECT HUB — main app shell.
// This component is the "manager": it loads data from the API,
// keeps it in memory, and passes it down to the four screens.

'use client'

import { useCallback, useEffect, useMemo, useState } from 'react'
import { Button } from '@/components/ui/button'
import { useToast } from '@/hooks/use-toast'
import { ThemeToggle } from '@/components/hub/theme-toggle'
import { DashboardView, type TabKey } from '@/components/hub/dashboard-view'
import { ProjectsView } from '@/components/hub/projects-view'
import { ClientsView } from '@/components/hub/clients-view'
import { TasksView } from '@/components/hub/tasks-view'
import { ProjectDialog, type ProjectFormValues } from '@/components/hub/project-dialog'
import { ClientDialog, type ClientFormValues } from '@/components/hub/client-dialog'
import { TaskDialog, type TaskFormValues } from '@/components/hub/task-dialog'
import { DeleteDialog } from '@/components/hub/delete-dialog'
import type { ClientItem, ProjectItem, TaskItem } from '@/lib/hub'
import { cn } from '@/lib/utils'
import { LayoutDashboard, FolderKanban, Users, ListChecks, Layers } from 'lucide-react'

// What can be deleted (so the confirm dialog knows what to say)
type DeleteTarget =
  | { kind: 'project'; item: ProjectItem }
  | { kind: 'client'; item: ClientItem }
  | { kind: 'task'; item: TaskItem }

const NAV_ITEMS: Array<{ key: TabKey; label: string; icon: React.ReactNode }> = [
  { key: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-4 w-4" /> },
  { key: 'projects', label: 'Projects', icon: <FolderKanban className="h-4 w-4" /> },
  { key: 'clients', label: 'Clients', icon: <Users className="h-4 w-4" /> },
  { key: 'tasks', label: 'Tasks', icon: <ListChecks className="h-4 w-4" /> },
]

export default function ProjectHubPage() {
  const { toast } = useToast()

  // ---------- Data in memory ----------
  const [tab, setTab] = useState<TabKey>('dashboard')
  const [projects, setProjects] = useState<ProjectItem[]>([])
  const [clients, setClients] = useState<ClientItem[]>([])
  const [loading, setLoading] = useState(true)

  // ---------- Dialog state ----------
  const [projectDialogOpen, setProjectDialogOpen] = useState(false)
  const [editingProject, setEditingProject] = useState<ProjectItem | null>(null)

  const [clientDialogOpen, setClientDialogOpen] = useState(false)
  const [editingClient, setEditingClient] = useState<ClientItem | null>(null)

  const [taskDialogOpen, setTaskDialogOpen] = useState(false)
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null)
  const [presetProjectId, setPresetProjectId] = useState<string | null>(null)

  const [deleteTarget, setDeleteTarget] = useState<DeleteTarget | null>(null)

  // ---------- Load data from the API ----------
  const refresh = useCallback(async () => {
    try {
      const [projectsRes, clientsRes] = await Promise.all([fetch('/api/projects'), fetch('/api/clients')])
      if (!projectsRes.ok || !clientsRes.ok) throw new Error('Request failed')
      setProjects((await projectsRes.json()) as ProjectItem[])
      setClients((await clientsRes.json()) as ClientItem[])
    } catch {
      toast({
        title: 'Could not load your data',
        description: 'Please refresh the page and try again.',
        variant: 'destructive',
      })
    } finally {
      setLoading(false)
    }
  }, [toast])

  useEffect(() => {
    refresh()
  }, [refresh])

  // ---------- Project actions ----------

  const openNewProject = () => {
    setEditingProject(null)
    setProjectDialogOpen(true)
  }

  const openEditProject = (project: ProjectItem) => {
    setEditingProject(project)
    setProjectDialogOpen(true)
  }

  async function submitProject(values: ProjectFormValues): Promise<boolean> {
    const isEdit = !!editingProject
    try {
      const res = await fetch(isEdit ? `/api/projects/${editingProject!.id}` : '/api/projects', {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      })
      if (!res.ok) throw new Error('Request failed')
      toast({ title: isEdit ? 'Project updated' : 'Project created', description: values.name })
      await refresh()
      return true
    } catch {
      toast({ title: 'Something went wrong', description: 'The project could not be saved.', variant: 'destructive' })
      return false
    }
  }

  // ---------- Client actions ----------

  const openNewClient = () => {
    setEditingClient(null)
    setClientDialogOpen(true)
  }

  const openEditClient = (client: ClientItem) => {
    setEditingClient(client)
    setClientDialogOpen(true)
  }

  async function submitClient(values: ClientFormValues): Promise<boolean> {
    const isEdit = !!editingClient
    try {
      const res = await fetch(isEdit ? `/api/clients/${editingClient!.id}` : '/api/clients', {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      })
      if (!res.ok) throw new Error('Request failed')
      toast({ title: isEdit ? 'Client updated' : 'Client added', description: values.name })
      await refresh()
      return true
    } catch {
      toast({ title: 'Something went wrong', description: 'The client could not be saved.', variant: 'destructive' })
      return false
    }
  }

  // ---------- Task actions ----------

  const openNewTask = (projectId?: string) => {
    setEditingTask(null)
    setPresetProjectId(projectId ?? null)
    setTaskDialogOpen(true)
  }

  const openEditTask = (task: TaskItem) => {
    setEditingTask(task)
    setPresetProjectId(null)
    setTaskDialogOpen(true)
  }

  async function submitTask(values: TaskFormValues): Promise<boolean> {
    const isEdit = !!editingTask
    try {
      const res = await fetch(isEdit ? `/api/tasks/${editingTask!.id}` : '/api/tasks', {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      })
      if (!res.ok) throw new Error('Request failed')
      toast({ title: isEdit ? 'Task updated' : 'Task added', description: values.title })
      await refresh()
      return true
    } catch {
      toast({ title: 'Something went wrong', description: 'The task could not be saved.', variant: 'destructive' })
      return false
    }
  }

  // Click the circle: To Do → In Progress → Done → back to To Do
  async function cycleTaskStatus(task: TaskItem) {
    const NEXT: Record<TaskItem['status'], TaskItem['status']> = {
      TODO: 'IN_PROGRESS',
      IN_PROGRESS: 'DONE',
      DONE: 'TODO',
    }
    const next = NEXT[task.status]
    // Optimistic update: change the screen right away, then confirm with the server
    setProjects((prev) =>
      prev.map((p) =>
        p.id === task.projectId
          ? { ...p, tasks: p.tasks.map((t) => (t.id === task.id ? { ...t, status: next } : t)) }
          : p
      )
    )
    try {
      const res = await fetch(`/api/tasks/${task.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: next }),
      })
      if (!res.ok) throw new Error('Request failed')
      await refresh()
    } catch {
      toast({ title: 'Could not update the task', variant: 'destructive' })
      await refresh() // put the old status back
    }
  }

  // ---------- Delete ----------

  async function confirmDelete() {
    if (!deleteTarget) return
    const { kind, item } = deleteTarget
    const path = kind === 'project' ? '/api/projects' : kind === 'client' ? '/api/clients' : '/api/tasks'
    try {
      const res = await fetch(`${path}/${item.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Request failed')
      toast({
        title:
          kind === 'project' ? 'Project deleted' : kind === 'client' ? 'Client deleted' : 'Task deleted',
        description: 'This change was saved.',
      })
      await refresh()
    } catch {
      toast({ title: 'Something went wrong', description: 'The item could not be deleted.', variant: 'destructive' })
    }
  }

  // ---------- Derived data ----------

  // A flat list of all tasks (each one tagged with its project name)
  const allTasks = useMemo<TaskItem[]>(
    () => projects.flatMap((p) => p.tasks.map((t) => ({ ...t, project: { id: p.id, name: p.name } }))),
    [projects]
  )

  // ---------- Rendering ----------

  return (
    <div className="flex min-h-screen flex-col">
      {/* ===== Header ===== */}
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between px-4 sm:px-6">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-sm">
              <Layers className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <p className="text-base font-extrabold tracking-tight">
                PROJECT <span className="text-primary">HUB</span>
              </p>
              <p className="hidden text-[11px] text-muted-foreground sm:block">
                Clients, projects &amp; deadlines — all in one place
              </p>
            </div>
          </div>

          {/* Desktop navigation */}
          <nav className="hidden items-center gap-1 md:flex" aria-label="Main navigation">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.key}
                onClick={() => setTab(item.key)}
                aria-current={tab === item.key ? 'page' : undefined}
                className={cn(
                  'flex items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-medium transition-colors',
                  tab === item.key
                    ? 'bg-primary/10 text-primary'
                    : 'text-muted-foreground hover:bg-accent hover:text-foreground'
                )}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </nav>

          <ThemeToggle />
        </div>
      </header>

      {/* ===== Main content ===== */}
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-28 pt-6 sm:px-6 md:pb-10 md:pt-8">
        {tab === 'dashboard' && (
          <DashboardView
            projects={projects}
            clients={clients}
            loading={loading}
            onNewProject={openNewProject}
            onEditProject={openEditProject}
            onNavigate={setTab}
          />
        )}
        {tab === 'projects' && (
          <ProjectsView
            projects={projects}
            loading={loading}
            onNew={openNewProject}
            onEdit={openEditProject}
            onDelete={(project) => setDeleteTarget({ kind: 'project', item: project })}
            onAddTask={(project) => openNewTask(project.id)}
          />
        )}
        {tab === 'clients' && (
          <ClientsView
            clients={clients}
            loading={loading}
            onNew={openNewClient}
            onEdit={openEditClient}
            onDelete={(client) => setDeleteTarget({ kind: 'client', item: client })}
          />
        )}
        {tab === 'tasks' && (
          <TasksView
            tasks={allTasks}
            projects={projects}
            loading={loading}
            onNew={() => openNewTask()}
            onEdit={openEditTask}
            onDelete={(task) => setDeleteTarget({ kind: 'task', item: task })}
            onCycleStatus={cycleTaskStatus}
          />
        )}
      </main>

      {/* ===== Footer (desktop) ===== */}
      <footer className="mt-auto hidden border-t md:block">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-6 py-4 text-xs text-muted-foreground">
          <p>
            PROJECT HUB — Clients, projects &amp; deadlines, all in one place.
          </p>
          <p>Your data is saved automatically.</p>
        </div>
      </footer>

      {/* ===== Mobile bottom navigation ===== */}
      <nav
        className="fixed inset-x-0 bottom-0 z-40 border-t bg-background/95 backdrop-blur-md md:hidden"
        aria-label="Mobile navigation"
        style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      >
        <div className="grid grid-cols-4">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.key}
              onClick={() => setTab(item.key)}
              aria-current={tab === item.key ? 'page' : undefined}
              className={cn(
                'flex min-h-[3.5rem] flex-col items-center justify-center gap-1 py-2 text-[11px] font-medium transition-colors',
                tab === item.key ? 'text-primary' : 'text-muted-foreground'
              )}
            >
              {item.icon}
              {item.label}
            </button>
          ))}
        </div>
      </nav>

      {/* ===== Dialogs (popups) ===== */}
      <ProjectDialog
        open={projectDialogOpen}
        onOpenChange={setProjectDialogOpen}
        project={editingProject}
        clients={clients}
        onSubmit={submitProject}
      />
      <ClientDialog
        open={clientDialogOpen}
        onOpenChange={setClientDialogOpen}
        client={editingClient}
        onSubmit={submitClient}
      />
      <TaskDialog
        open={taskDialogOpen}
        onOpenChange={setTaskDialogOpen}
        task={editingTask}
        taskProjectId={presetProjectId}
        projects={projects}
        onSubmit={submitTask}
      />
      <DeleteDialog
        open={!!deleteTarget}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null)
        }}
        title={
          deleteTarget?.kind === 'project'
            ? 'Delete this project?'
            : deleteTarget?.kind === 'client'
              ? 'Delete this client?'
              : 'Delete this task?'
        }
        description={
          deleteTarget?.kind === 'project'
            ? `"${deleteTarget.item.name}" and all of its tasks will be permanently removed.`
            : deleteTarget?.kind === 'client'
              ? `"${deleteTarget.item.name}" will be removed. Their projects will stay, but without a linked client.`
              : deleteTarget
                ? `"${deleteTarget.item.title}" will be permanently removed.`
                : ''
        }
        onConfirm={confirmDelete}
      />
    </div>
  )
}
