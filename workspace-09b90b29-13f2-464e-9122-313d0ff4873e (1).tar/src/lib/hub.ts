// This file is the "shared vocabulary" of the app.
// It defines what a Client, Project and Task look like in our code,
// plus small helper functions used everywhere (progress %, date formatting, badge colors).

// ---------- Types (shapes of our data) ----------

export type ProjectStatus = 'PLANNING' | 'IN_PROGRESS' | 'ON_HOLD' | 'COMPLETED'
export type ProjectPriority = 'LOW' | 'MEDIUM' | 'HIGH'
export type TaskStatus = 'TODO' | 'IN_PROGRESS' | 'DONE'

// A task, exactly as it comes from the API
export interface TaskItem {
  id: string
  title: string
  status: TaskStatus
  dueDate: string | null
  projectId: string
  project?: { id: string; name: string }
  createdAt: string
  updatedAt: string
}

// A project, with its client and its tasks attached
export interface ProjectItem {
  id: string
  name: string
  description: string | null
  status: ProjectStatus
  priority: ProjectPriority
  deadline: string | null
  clientId: string | null
  client?: { id: string; name: string; company: string | null } | null
  tasks: TaskItem[]
  createdAt: string
  updatedAt: string
}

// A client, with a counter of how many projects it has
export interface ClientItem {
  id: string
  name: string
  company: string | null
  email: string | null
  phone: string | null
  _count?: { projects: number }
  createdAt: string
  updatedAt: string
}

// ---------- Progress helpers ----------

// Progress = finished tasks ÷ total tasks. Completed projects are always 100%.
export function projectProgress(project: ProjectItem): number {
  if (project.status === 'COMPLETED') return 100
  const total = project.tasks.length
  if (total === 0) return 0
  const done = project.tasks.filter((t) => t.status === 'DONE').length
  return Math.round((done / total) * 100)
}

// Days from today (UTC) until a date. Negative = overdue.
export function daysUntil(iso: string): number {
  const today = new Date()
  today.setUTCHours(0, 0, 0, 0)
  const target = new Date(iso)
  target.setUTCHours(0, 0, 0, 0)
  return Math.round((target.getTime() - today.getTime()) / 86400000)
}

// "Jan 15, 2026" style. timeZone UTC because we save dates at UTC midnight.
export function formatDate(iso: string | null | undefined): string {
  if (!iso) return 'No date'
  return new Date(iso).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    timeZone: 'UTC',
  })
}

// API stores "2026-01-15T00:00:00Z" — the <input type="date"> wants "2026-01-15"
export function toDateInput(iso: string | null | undefined): string {
  if (!iso) return ''
  return iso.slice(0, 10)
}

// Human-friendly words for a deadline
export function deadlineLabel(iso: string | null): { text: string; tone: 'danger' | 'warn' | 'ok' | 'muted' } {
  if (!iso) return { text: 'No deadline', tone: 'muted' }
  const days = daysUntil(iso)
  if (days < 0) return { text: `${Math.abs(days)}d overdue`, tone: 'danger' }
  if (days === 0) return { text: 'Due today', tone: 'warn' }
  if (days === 1) return { text: 'Due tomorrow', tone: 'warn' }
  if (days <= 7) return { text: `Due in ${days} days`, tone: 'warn' }
  return { text: `Due ${formatDate(iso)}`, tone: 'ok' }
}

// ---------- Badge color styles ----------

// Each tone maps to light AND dark mode classes
const TONE_CLASSES = {
  slate: 'bg-slate-100 text-slate-600 border-slate-200 dark:bg-slate-500/15 dark:text-slate-300 dark:border-slate-500/20',
  emerald: 'bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/20',
  amber: 'bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/20',
  rose: 'bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/20',
  violet: 'bg-violet-100 text-violet-700 border-violet-200 dark:bg-violet-500/15 dark:text-violet-300 dark:border-violet-500/20',
  orange: 'bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-500/15 dark:text-orange-300 dark:border-orange-500/20',
} as const

export type Tone = keyof typeof TONE_CLASSES

export const PROJECT_STATUS_CONFIG: Record<ProjectStatus, { label: string; tone: Tone }> = {
  PLANNING: { label: 'Planning', tone: 'amber' },
  IN_PROGRESS: { label: 'In Progress', tone: 'emerald' },
  ON_HOLD: { label: 'On Hold', tone: 'orange' },
  COMPLETED: { label: 'Completed', tone: 'slate' },
}

export const PRIORITY_CONFIG: Record<ProjectPriority, { label: string; tone: Tone }> = {
  HIGH: { label: 'High', tone: 'rose' },
  MEDIUM: { label: 'Medium', tone: 'amber' },
  LOW: { label: 'Low', tone: 'slate' },
}

export const TASK_STATUS_CONFIG: Record<TaskStatus, { label: string; tone: Tone }> = {
  TODO: { label: 'To Do', tone: 'slate' },
  IN_PROGRESS: { label: 'In Progress', tone: 'violet' },
  DONE: { label: 'Done', tone: 'emerald' },
}

export function toneClasses(tone: Tone): string {
  return TONE_CLASSES[tone]
}

// Initials for client avatars, e.g. "Sarah Mitchell" → "SM"
export function initials(name: string): string {
  return name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]!.toUpperCase())
    .join('')
}
